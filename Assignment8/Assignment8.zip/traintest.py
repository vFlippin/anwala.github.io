#traintest.py
import sys
import docclass
import os

cl = docclass.naivebayes(docclass.getwords)
#remove previous db file
#check_output(['rm', 'testobj.db'])

cl.setdb('testobj.db')
docclass.spamTrain(cl)


#train
#for file in folder train
for file in os.listdir('trainspam'):
  sys.stdout.write(file)
  #read file, train
  infile = open('./trainspam/' +file,'r')
  cl.train(infile.read(), 'spam')
  infile.close()
for file in os.listdir('trainnotspam'):
  sys.stdout.write(file)
  #read file, train
  infile = open('./trainnotspam/' +file,'r')
  cl.train(infile.read(), 'not spam')
  infile.close()
  
#test
for file in os.listdir('testspam'):
  sys.stdout.write(file + "   ")
  #read file, train
  infile = open('./testspam/' +file,'r')
  print( cl.classify(infile.read()) )
  infile.close()
for file in os.listdir('testnotspam'):
  sys.stdout.write(file  + "   ")
  #read file, train
  infile = open('./testnotspam/' +file,'r')
  print( cl.classify(infile.read()))
  infile.close()