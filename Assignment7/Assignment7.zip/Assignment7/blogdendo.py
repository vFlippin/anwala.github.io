#blogdendo.py

import clusters
import sys

#out=open('blogdendo1.txt','w')

#drawdendrogram(clust, labels, jpeg='clusters.jpg') // img.save(jpeg, 'JPEG')
#readfile(filename) //return (rownames, colnames, data)
#kcluster(rows, distance=pearson, k=4) //return bestmatches



blognames,words,data=clusters.readfile('blogdata1.txt') # returns blog titles, words in blog (10%-50% boundaries), list of frequency info
clust=clusters.hcluster(data) # returns a tree of foo.id, foo.left, foo.right
sys.stdout = open('asciidendo.txt', 'w')
clusters.printclust(clust,labels=blognames) # walks tree and prints ascii approximation of a dendogram; distance measure is Pearson's r
clusters.drawdendrogram(clust,blognames)