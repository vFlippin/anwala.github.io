#kclusters.py

import clusters
import sys

blognames,words,data=clusters.readfile('blogdata1.txt') # returns blog titles, words in blog (10%-50% boundaries), list of frequency info
clust=clusters.hcluster(data) # returns a tree of foo.id, foo.left, foo.right
sys.stdout = open('kclusters.txt', 'w')
print('k=5')
kclust=clusters.kcluster(data,k=5)
print('')
print('k=10')
kclust=clusters.kcluster(data,k=10)
print('')
print('k=20')
kclust=clusters.kcluster(data,k=20)