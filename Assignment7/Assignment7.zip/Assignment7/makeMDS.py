#makeMDS.py

import clusters
import sys

blognames,words,data=clusters.readfile('blogdata1.txt') # returns blog titles, words in blog (10%-50% boundaries), list of frequency info

sys.stdout = open('MDSout.txt', 'w')
coords=clusters.scaledown(data)

clusters.draw2d(coords,blognames,jpeg='MDS.jpg')
