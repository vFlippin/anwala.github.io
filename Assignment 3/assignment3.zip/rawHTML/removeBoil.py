#import justext
import sys
import os
import re
#from urllib.request import urlopen
#import requests
#from goose3 import Goose



directory = os.fsencode(sys.argv[1])
#g=Goose()
for file in os.listdir(directory):
    filename = file.strip()
    if filename.endswith(b'.html'):
        try:
            openfile = open(file, 'r')
            rawtext = openfile.read()
            #text = clean_html(rawtext)
            
            # First we remove inline JavaScript/CSS:
            cleaned = re.sub(r"(?is)<(script|style).*?>.*?(</\1>)", "", rawtext.strip())
            # Then we remove html comments. This has to be done before removing regular
            # tags since comments can contain '>' characters.
            cleaned = re.sub(r"(?s)<!--(.*?)-->[\n]?", "", cleaned)
            # Next we can remove the remaining tags:
            cleaned = re.sub(r"(?s)<.*?>", " ", cleaned)
            # Finally, we deal with whitespace
            cleaned = re.sub(r"&nbsp;", " ", cleaned)
            cleaned = re.sub(r"  ", " ", cleaned)
            cleaned = re.sub(r"  ", " ", cleaned)

            #my addition to remove blank lines
            cleaned = re.sub("\n\s*\n*", "\n", cleaned)
        
        
            #os.system(str(cleaned) + ' > ~/ass3/rawHTML/textFiles/' + str(filename) + '.txt ')
            openfile.close()
            
            with open(str(filename.decode("utf-8"))+ '.txt', 'w') as f:
                print(cleaned, file=f)
        except:
            continue
        else:
            continue 