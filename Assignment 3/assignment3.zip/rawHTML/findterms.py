import os
import sys

directory = os.fsencode(sys.argv[1])
checkedpos = 0
checked = 0
files = 0
for file in os.listdir(directory):
    files = files + 1
    filename = file.strip()
    #if str(filename).endswith('html.txt'):
    try:
        count = 0
        word = 'heist'
        with open(filename, 'r') as f:
            checked = checked + 1
            for line in f:
                words = line.split()
                for i in words:
                    if(i==word):
                        count=count+1
                
        if count > 0:
            
            num_words = 0
            with open(filename, 'r') as f:
                for line in f:
                    words = line.split()
                    num_words += len(words)
                        
                    
                    
            print(str(count) + ' heist occurance out of '+ num_words + ' in file ' + filename)
            checkedpos = checkedpos +1
    except:
        continue
print(str(checked) + ' files of ' + str(files) + ' files checked, '+str(checkedpos)+' files with matches')