import hashlib
import sys
import os

input_file = open(sys.argv[1],'r')

for line in input_file:
    site = line.strip()

    #make md5 hash name
    m = hashlib.md5()
    name = site
    #os.system(' echo -n ' + name)
    name2 = name.encode('utf-8')
    #os.system(' echo -n ' + str(name2))
    m.update(name2)
    hname = m.hexdigest()
    #os.system(' echo -n ' + hname)
    #make file to be imported to
    print(hname + '.html')
    #run os command to get web page, put into made file
    os.system('curl '+ site + ' > ' + hname + '.html ')
    #data = site.read()
    #file = open("testout.txt","wb") #open file in binary mode
    #file.writelines(data)
    #file.close()

#curl  http://www.cs.odu.edu/~410yello/  >  "http://www.cs.odu.edu/~410yello/"  | md5sum