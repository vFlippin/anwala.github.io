import sys
import re

filecount = int(sys.argv[1])
#outfile = (sys.argv[2], 'r')
countArr = []
print('x       y'+'\n')
for x in range (1, filecount):
    fname = str(x)+'timemap.txt'
    fname = fname.strip()
 
    count = 0
    
 
    with open(fname, 'r') as f:
        
        contents = f.read()
        count = sum(1 for match in re.finditer(r"\memento\b", contents))
        print('null    ' + str(count))
        
        

    
