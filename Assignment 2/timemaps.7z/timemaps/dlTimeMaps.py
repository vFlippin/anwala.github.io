import sys
from urllib.request import urlopen
from urllib.request import urlretrieve
#import html2text

def genericErrorInfo():
	import os, sys
	exc_type, exc_obj, exc_tb = sys.exc_info()
	fname = os.path.split(exc_tb.tb_frame.f_code.co_filename)[1]
	errorMessage = fname + ', ' + str(exc_tb.tb_lineno)  + ', ' + str(sys.exc_info())
	print('\tERROR:', errorMessage)

input_file = open(sys.argv[1],'r')
lineCount = 1
for line in input_file:
    
    url = line.strip()
    filename = str(lineCount) +"timemap.txt"
    print (str(lineCount))
    
    try:
        timeMapurl = 'http://memgator.cs.odu.edu/timemap/link/' + url
        #response = urlopen(timeMapurl)
        #page = response.read()
        #outputText = html2text.html2text(page)
        #filename = str(lineCount) +"timemap.txt"
        #output_file = open(filename, 'wb+')
        #with open (filename) as output_file:
        #output_file.write(page)
        #output_file.close()
        
        urlretrieve (timeMapurl , filename)
        lineCount = lineCount + 1
        
    
    except:
        outfile= open(filename, 'w+')
        outfile.write('failed')
        outfile.close()
        genericErrorInfo()
        lineCount = lineCount + 1
        continue
        
    