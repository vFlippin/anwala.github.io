import sys
import re

filecount = int(sys.argv[1])
#outfile = (sys.argv[2], 'r')
countArr = []
for x in range (1, filecount):
    fname = str(x)+'timemap.txt'
    fname = fname.strip()
 
    count = 0
    
 
    with open(fname, 'r') as f:
        
        contents = f.read()
        count = sum(1 for match in re.finditer(r"\memento\b", contents))
        
        if len(countArr) < (count + 1):
            while len(countArr) < (count + 1):
                countArr = countArr + [0]
      
        countArr[count] = countArr[count] + 1
        
for y in range (0, len(countArr) ):
    print(str(countArr[y]))
