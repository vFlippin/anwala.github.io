import tweepy, sys

#infile = sys.argv[1] #input file
#outfile = sys.argv[2]


 
global api
consumer_key = "B5bqvMF1YcvWSXkjQ1IM2JJFj"
consumer_secret = "nksLmNL0IVvKoK5OaBrWAr4UJhGD8o9nzvRvpHOQUaAE20RWqH"
access_key = "367451421-uHFwpmINorzC9krB5NNXbByq2lnLjAfXweEULfe7"
access_secret = "0uBi2FTWEVyKaHvAzyNq5NuU3Z3OcAvD5eTy3vlezTHPN"
auth = tweepy.OAuthHandler(consumer_key, consumer_secret)
auth.set_access_token(access_key, access_secret)
api = tweepy.API(auth)

user = api.get_user('acnwala')
name = str(user.screen_name)
count = str(user.followers_count)
print (name + ' , ' + count)
