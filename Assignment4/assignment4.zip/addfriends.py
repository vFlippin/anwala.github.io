#addfriends.py
#do calculations on freinds to see if friendship paradox holds
#will take .csv file with format "USER, FRIENDCOUNT"

#import csv
import sys
import pandas as pd
#import numpy as np

#from collections import Counter

infile = sys.argv[1] #input file
outfile = sys.argv[2] #output file
 
fields = ['USER', 'FRIENDCOUNT']
df = pd.read_csv(infile, encoding="utf-8-sig", skipinitialspace=True, usecols=fields)
fmean = df['FRIENDCOUNT'].mean()
fmedian = df['FRIENDCOUNT'].median()
fstd = df['FRIENDCOUNT'].std()

print("mean = " + str(fmean), file=open(outfile, "a"))
print("meadian = " + str(fmedian), file=open(outfile, "a"))
print("standard deviation = " + str(fstd), file=open(outfile, "a"))
