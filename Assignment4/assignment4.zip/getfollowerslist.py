import tweepy, sys, time

from secrets import *


outfile = sys.argv[1]

global api
consumer_key = "B5bqvMF1YcvWSXkjQ1IM2JJFj"
consumer_secret = "nksLmNL0IVvKoK5OaBrWAr4UJhGD8o9nzvRvpHOQUaAE20RWqH"
access_key = "367451421-uHFwpmINorzC9krB5NNXbByq2lnLjAfXweEULfe7"
access_secret = "0uBi2FTWEVyKaHvAzyNq5NuU3Z3OcAvD5eTy3vlezTHPN"
auth = tweepy.OAuthHandler(consumer_key, consumer_secret)
auth.set_access_token(access_key, access_secret)
api = tweepy.API(auth)

users = tweepy.Cursor(api.followers, screen_name="acnwala").items()

print('"USER", "FRIENDCOUNT"', file=open(outfile, "a"))

while True:
    try:
        user = next(users)
    except tweepy.TweepError:
        time.sleep(60*15)
        user = next(users)
    except StopIteration:
        break
    #print (user.screen_name, file=open(outfile, "a"))
    name = str(user.screen_name)
    count = str(user.followers_count)
    print (name + ' , ' + count, file=open(outfile, "a"))