#makegraph.py

import matplotlib.pyplot as plt

#import numpy as np
import pandas as pd

import sys

infile = sys.argv[1]
fields = ['USER', 'FRIENDCOUNT']
df = pd.read_csv(infile, encoding="utf-8-sig", skipinitialspace=True, usecols=fields)
#df.plot(kind='scatter', x='USER', y='FRIENDCOUNT')
#plt.show(block=True)

df2 = result = df.sort_values(by=['FRIENDCOUNT'])


plt.scatter(df2['USER'], df2['FRIENDCOUNT'])

plt.axhline(y=196)
plt.ylim((0,3000))
plt.tick_params(
    axis='x',          # changes apply to the x-axis
    which='both',      # both major and minor ticks are affected
    bottom='off',      # ticks along the bottom edge are off
    top='off',         # ticks along the top edge are off
    labelbottom='off') # labels along the bottom edge are off
plt.show()
plt.savefig('followergraph.png')