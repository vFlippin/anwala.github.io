"""
Zachary's Karate Club graph

Data file from:
http://vlado.fmf.uni-lj.si/pub/networks/data/Ucinet/UciData.htm

Reference:
Zachary W. (1977).
An information flow model for conflict and fission in small groups.
Journal of Anthropological Research, 33, 452-473.
"""
import networkx as nx
import igraph

G=nx.karate_club_graph()
print("Node Degree")
for v in G:
    print('%s %s' % (v,G.degree(v)))
    
g = igraph.Graph()
g = igraph.Graph.Read_Edgelist("karateEdges.txt")
print(g)

layout = g.layout_fruchterman_reingold()
igraph.plot(g, layout = layout)

for x in range (0,10):
    g.community_edge_betweenness()
    
    layout = g.layout_fruchterman_reingold()
    igraph.plot(g, layout = layout)